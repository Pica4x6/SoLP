var zero = false

function setIconCounter(){
    var clicks = 0;
    zero = false
    // chrome.browserAction.setBadgeText({text: (0).toString()});
    var url = chrome.runtime.getURL('data/apps_v1_www.json');
    var myJson = fetch(url)
        .then(function (response) {
            return response.json();
        })
        .then(function (myJsonv1) {
            var url2 = chrome.runtime.getURL('data/apps_v2_www.json');
            var myJsonv2 = fetch(url2)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJsonv2) {
                    var url3 = chrome.runtime.getURL('data/apps_hosted_www.json');
                    var myJsonv3 = fetch(url3)
                        .then(function (response) {
                            return response.json();
                        })
                        .then(function (myJsonv3) {
                            var url4 = chrome.runtime.getURL('data/browser_extensions_www.json');
                            var myJsonv4 = fetch(url4)
                                .then(function (response) {
                                    return response.json();
                                })
                                .then(function (myJsonv4) {
                                    chrome.management.getAll(function (extInfos) {
                                        extInfos.forEach(function (ext) {
                                            if (ext.enabled) {
                                                var aux = ext.id
                                                var myJson = false
                                                if (myJsonv1.hasOwnProperty(aux)) {
                                                    myJson = myJsonv1
                                                } else if (myJsonv2.hasOwnProperty(aux)) {
                                                    myJson = myJsonv2
                                                } else if (myJsonv3.hasOwnProperty(aux)) {
                                                    myJson = myJsonv3
                                                } else if (myJsonv4.hasOwnProperty(aux)) {
                                                    console.log(aux, ' is a Browser Extension')
                                                    myJson = myJsonv4
                                                } else {
                                                    console.log("Not known Extension")
                                                }
                                                if (myJson) {
                                                    if (myJson[aux].overprivileged) {
                                                        zero = true;
                                                        chrome.browserAction.setBadgeText({text: (++clicks).toString()});
                                                    }
                                                }
                                            }
                                        })
                                        if (zero == false) {
                                            chrome.browserAction.setBadgeText({text: (0).toString()});
                                        }
                                    });
                                });
                        })
                })

        });
}


chrome.extension.onConnect.addListener(function(port) {
    get_over_extensions(port)
});

function got(info) {
  console.log(info.name);
}

function get_over_extensions(port) {
    var clicks = 0;
    zero = false
    var url = chrome.runtime.getURL('data/apps_v1_www.json');
    var myJson = fetch(url)
        .then(function (response) {
            return response.json();
        })
        .then(function (myJsonv1) {
            var url2 = chrome.runtime.getURL('data/apps_v2_www.json');
            var myJsonv2 = fetch(url2)
                .then(function (response) {
                    return response.json();
                })
                .then(function (myJsonv2) {
                    var url3 = chrome.runtime.getURL('data/apps_hosted_www.json');
                    var myJsonv3 = fetch(url3)
                        .then(function (response) {
                            return response.json();
                        })
                        .then(function (myJsonv3) {
                            var url4 = chrome.runtime.getURL('data/browser_extensions_www.json');
                            var myJsonv4 = fetch(url4)
                                .then(function (response) {
                                    return response.json();
                                })
                                .then(function (myJsonv4) {
                                    chrome.management.getAll(function (extInfos) {
                                        extInfos.forEach(function (ext) {
                                            if (ext.enabled) {
                                                var aux = ext.id
                                                var myJson = false
                                                if (myJsonv1.hasOwnProperty(aux)) {
                                                    console.log(aux, ' is a Packaged v1 app')
                                                    myJson = myJsonv1
                                                } else if (myJsonv2.hasOwnProperty(aux)) {
                                                    console.log(aux, ' is a Packaged v2 app')
                                                    myJson = myJsonv2
                                                } else if (myJsonv3.hasOwnProperty(aux)) {
                                                    console.log(aux, ' is a Hosted app')
                                                    myJson = myJsonv3
                                                } else if (myJsonv4.hasOwnProperty(aux)) {
                                                    console.log(aux, ' is a Browser Extension')
                                                    myJson = myJsonv4
                                                } else {
                                                    console.log("Not known Extension")
                                                }
                                                if (myJson) {
                                                    console.log('is ' + aux + ' overprivileged? ' + myJson[aux].overprivileged)
                                                    if (myJson[aux].overprivileged) {
                                                        zero = true;
                                                        chrome.browserAction.setBadgeText({text: (++clicks).toString()});
                                                        port.postMessage({data: myJson[aux], id: aux});

                                                    }
                                                }
                                            }
                                        })
                                        if (zero == false) {
                                            chrome.browserAction.setBadgeText({text: (0).toString()});
                                        }
                                    });
                                });
                        });
                });
        });
}

setIconCounter()
chrome.management.onInstalled.addListener(setIconCounter)
chrome.management.onUninstalled.addListener(setIconCounter)
chrome.management.onEnabled.addListener(setIconCounter)
chrome.management.onDisabled.addListener(setIconCounter)
