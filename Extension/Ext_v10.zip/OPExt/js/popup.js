function addExtension(msg) {
    var table = document.getElementById("table:extensions");

    var row = table.insertRow(table.rows.length);

    // Insert new cells (<td> elements) at the 1st and 2nd position of the "new" <tr> element:
    var id = row.insertCell(0);
    var permissions = row.insertCell(1);
    var api = row.insertCell(2);

    // Add some text to the new cells:
    id.innerHTML = msg.id;
    permissions.innerHTML = msg.data.permissions.toString().replace(/,/g,"<br />");
    for (elem in msg.data.files){
        console.log(msg.data.files[elem])
        for (key in msg.data.files[elem]){
            console.log(msg.data.files[elem][key])
            api.innerHTML += "<p><b>" +  key + ": </b><br />" + msg.data.files[elem][key].toString().replace(/,/g,"<br />") + "</p>";
        }
    }
}


var port = chrome.extension.connect({
    name: "OPExt"
});
port.onMessage.addListener(function(msg) {
    addExtension(msg)
});