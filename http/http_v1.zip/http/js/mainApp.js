var app = angular.module('myApp', ['ngAnimate', 'ngSanitize', 'ui.bootstrap']);
app.controller('myCtrl', function($scope, $http, $timeout,$window, $log ) {
    $scope.files = [];
    $scope.fileShow = '';
    $scope.filesShowPage = [];
    $scope.load = false;
    $scope.name = '';
    // $scope.maxSize = 100;
    // $scope.totalItems = 0;
    // $scope.currentPage = 1;
    // $scope.maxShowSize = 5;
    angular.element($window).bind('resize', function(){
        $('#sidebar').removeClass('collapse');
    });

  $scope.lengthObj = function(obj) {
    return Object.keys(obj).length;
  }
  $scope.changeFiles= function(file, id, name){
    $scope.name =  name;
    $('.nav-link').removeClass('active')
    $('#'+id).addClass('active');
    $scope.load = false;
    $scope.fileShow = file;
    $http.get(file)
    .then(function(response) {
      $scope.closeTabs();
        $scope.files = Object.entries(response.data);
        $timeout(function(){
          $scope.bigTotalItems = $scope.files.length;
           var begin = (($scope.currentPage - 1) * $scope.maxSize)
              , end = begin + $scope.maxSize;
          $scope.filesShowPage = Object.entries($scope.files).slice(begin, end);
          $scope.load = true;
        }); 
    });
  }
  $scope.totalItems = 1;
  $scope.currentPage = 1;

  $scope.setPage = function (pageNo) {
    $scope.currentPage = pageNo;
  };
  $scope.pageChanged = function(data) {
    var begin = ((data - 1) * $scope.maxSize)
    , end = begin + $scope.maxSize;
    $scope.filesShowPage = Object.entries($scope.files).slice(begin, end);
    $scope.closeTabs();
  };
  $scope.closeTabs= function(){
    $('.title-link').addClass('collapsed');
    $('.title-link').attr('aria-expanded', false);
    $('.title-link').each(function(){
      $($(this).attr('data-target')).removeClass('show');
    })
  }
  //$scope.pageChanged = function() {
    // $log.log('Page changed to: ' + $scope.currentPage);
    // var begin = (($scope.currentPage - 1) * $scope.maxSize)
    //       , end = begin + $scope.maxSize;
    // $scope.load = false;
    // $timeout(function(){
    //   $scope.filesShowPage = $scope.files.slice(begin, end);
    //   $scope.load = true;
    // });
  //};

  $scope.maxSize = 6;
  $scope.bigCurrentPage = 1;

});