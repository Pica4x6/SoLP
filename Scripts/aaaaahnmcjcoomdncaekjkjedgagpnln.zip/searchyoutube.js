function searchyoutube(info)
{ 
 var searchstring = info.selectionText;
 chrome.tabs.create({url: "http://www.youtube.com/results?search_query=" + searchstring})
}

var titleString = "Search Youtube for '%s'";
chrome.contextMenus.create({title:titleString, contexts:["selection"], onclick: searchyoutube});

